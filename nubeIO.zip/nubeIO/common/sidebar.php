<div class="sidebar right">
    <div class="sidebar-wrapper">
        <form class="search-form animated fadeInUp" action="#">
            <input type="text" class="form-control" name="search" placeholder="Search" required="">
            <button type="submit"><i class="fa fa-search"></i></button>
            
        </form>
        
        <div class="sidebar-categories">
            <div class="list">
                <form class="subscribe-form fadeInUp" action="">
                    <input type="email" class="form-control" name="email" placeholder="E-mail" required="">
                    <button type="submit" class="btn-subscribe btn-secondary-box">Subscribe</button>
                </form>
            </div>
        </div>
        
        <div class="sidebar-categories">
           <h2>Categories</h2>
            <div class="list">
                <ul>
                    <li>
                        <a href="/blog.php">Company News(5)</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="sidebar-categories popular-post">
            <h2>Popular Post</h2>
            <div class="post list">
              
                    <div class="post-item">
                        <a href="blog-cart1.php">
                            <img src="/assets/images/image1.jpg" alt="">
                        </a>
                        <div>
                            <a href="blog-cart1.php">
                                CBA Starts Work with Nube iO
                            </a>   
                            <p class="date">
                                <i class="fa fa-calendar-o"></i>
                                May 20, 2018
                            </p>
                        </div>
                    </div>

                    <div class="post-item">
                        <a href="blog-cart2.php">
                            <img src="/assets/images/image2.jpg" alt="">
                        </a>
                        <div>
                            <a href="blog-cart2.php">
                                Nube iO Announces Project with UOW
                            </a>   
                            <p class="date">
                                <i class="fa fa-calendar-o"></i>
                                April 15, 2018
                            </p>
                        </div>
                    </div>

                    <div class="post-item">
                        <a href="blog-cart3.php">
                            <img src="/assets/images/image3.jpg" alt="">
                        </a>
                        <div>
                            <a href="blog-cart3.php">
                                Nube iO Signs New Client - Westpac
                            </a>   
                            <p class="date">
                                <i class="fa fa-calendar-o"></i>
                                May 03, 2018
                            </p>
                        </div>
                    </div>
             
            </div>
        </div>
    </div>
</div>