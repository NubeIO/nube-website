<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Arda - Bitcoin and Cryptocurrency ICO Template</title>
	<meta name ="title" content=«ЧП Матвиенко. Шины и диски»>
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<!-- Favicon -->
	<link rel="icon" type="image/png" href="assets/images/favicon.png" />

	<!-- Bootstrap & Plugins CSS -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<link href="assets/css/animate.min.css" rel="stylesheet" type="text/css">
	
    <!-- Swiper Slider-->
    <link href="assets/css/swiper.min.css" rel="stylesheet" type="text/css">
    
	<!-- Custom CSS -->
	<link href="assets/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/owl.theme.default.min.css" rel="stylesheet" type="text/css">
	<link href="assets/css/blue.css" rel="stylesheet" type="text/css">
	<link href="assets/css/controller.css" rel="stylesheet" type="text/css">
	
    <!-- REMODAL CSS-->
    <link href="assets/css/remodal.css" rel="stylesheet" type="text/css">
    <link href="assets/css/remodal-default-theme.css" rel="stylesheet" type="text/css">
	
</head>